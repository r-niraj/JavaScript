// import {default as rajnish} from './library.js';
import rajnish from './library.js';
import { message, user} from "./library.js";

rajnish();
user()
console.log(message);


// import { message, user as us, test } from "./library.js";
// import * as rajnish from "./library.js";
// console.log(rajnish.message);

// document.body.innerHTML = rajnish.message;

// // user('Amit Kumar');
// console.log(rajnish.user('Amit Kumar'));

// let a = new rajnish.test();
